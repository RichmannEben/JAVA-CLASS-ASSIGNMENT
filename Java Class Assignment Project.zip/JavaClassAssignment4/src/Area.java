import java.util.Scanner;
public class Area {
	int length;
	  int breadth;
	  public Area(int l, int b){
	    length = l;
	    breadth = b;
	  }
	  public int getArea(){
	    return length*breadth;

}
}
