
public class MainQ2 {

	public static void main(String[] args) {
		Triangle t = new Triangle();
		 t.a= 2;
		 t.b= 5;
		 t.c= 6;
		 System.out.println(t.getArea());
		 System.out.println(t.getPerimeter());
		
   }

 }
