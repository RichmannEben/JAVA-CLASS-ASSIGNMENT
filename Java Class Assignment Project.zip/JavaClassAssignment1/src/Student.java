
public class Student {
 String name;
 int roll_no;

}
